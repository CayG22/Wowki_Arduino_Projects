const int lowestPin = 2;
const int highestPin = 5;

void setup() {
  // put your setup code here, to run once:

}

void loop() {
  // put your main code here, to run repeatedly:
  for(int thisPin = lowestPin; thisPin <= highestPin; thisPin++){
    for(int brightness = 0; brightness < 255; brightness++){
      analogWrite(thisPin,brightness);
      delay(2);
    }

    for(int brightness = 255; brightness >= 0; brightness--){
      analogWrite(thisPin,brightness);
      delay(2);
    }

    delay(100);
  }
}
