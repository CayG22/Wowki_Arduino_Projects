int pushButton = 2;

void setup() {
  Serial.begin(9600);// Init. serial communication at 9600 bits per second
  pinMode(pushButton,INPUT);
}

void loop() {
  int buttonState = digitalRead(pushButton);
  Serial.println(buttonState);
  delay(1);
}
