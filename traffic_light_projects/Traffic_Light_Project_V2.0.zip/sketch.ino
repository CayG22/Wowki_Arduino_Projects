const int greenLight = 11;
const int yellowLight = 10;
const int redLight = 9;
const int _switch = 7;
int numberOfCars = 0;

enum TrafficState{
  RED,
  GREEN,
  YELLOW
};

TrafficState currentState = RED;

unsigned long previousMillis = 0;
void setup() {
  Serial.begin(9600);
  // put your setup code here, to run once:
  pinMode(greenLight, OUTPUT);
  pinMode(yellowLight,OUTPUT);
  pinMode(redLight,OUTPUT);
  pinMode(_switch, INPUT_PULLUP);

  digitalWrite(redLight, HIGH);
}

void setLightsToRed(){
  digitalWrite(greenLight,LOW);
  digitalWrite(yellowLight,LOW);
  digitalWrite(redLight,HIGH);
}

void loop() {

  unsigned long currentMillis = millis();

  switch(currentState){
    case RED:
      if(digitalRead(_switch) == LOW){
        digitalWrite(redLight,LOW);
        digitalWrite(greenLight,HIGH);

        currentState = GREEN;
        previousMillis = currentMillis;
      }
      break;
    case GREEN:
      if(currentMillis - previousMillis >= 5000){
        digitalWrite(greenLight,LOW);
        digitalWrite(yellowLight,HIGH);

        currentState = YELLOW;
        previousMillis = currentMillis;
      }
      break;
    case YELLOW:
      if(currentMillis - previousMillis >= 3000){
        digitalWrite(yellowLight,LOW);
        digitalWrite(redLight,HIGH);

        currentState = RED;
        previousMillis = currentMillis;
      }
      break;
  }

}


