const int greenLight = 11;
const int yellowLight = 10;
const int redLight = 9;
const int _switch = 7;
int numberOfCars = 0;
void setup() {
  Serial.begin(9600);
  // put your setup code here, to run once:
  pinMode(greenLight, OUTPUT);
  pinMode(yellowLight,OUTPUT);
  pinMode(redLight,OUTPUT);
  pinMode(_switch, INPUT_PULLUP);
}

void setLightsToRed(){
  digitalWrite(greenLight,LOW);
  digitalWrite(yellowLight,LOW);
  digitalWrite(redLight,HIGH);
}

void loop() {
  int switchState = digitalRead(_switch);
  if(switchState == HIGH)
    Serial.println("NO CARS PRESENT");
  else
    Serial.println("CARS PRESENT");
  if(switchState == HIGH){
    // If a car is not present, then we stay on red
    setLightsToRed();

  }else{
    // If red light is on turn it off
    if(digitalRead(redLight) == HIGH) digitalWrite(redLight,LOW);
    // If car is present, we turn green, wait for 5 seconds
    digitalWrite(greenLight, HIGH);
    delay(5000);
    digitalWrite(greenLight,LOW);
    digitalWrite(yellowLight,HIGH);
    delay(3000);
    digitalWrite(yellowLight,LOW);
    digitalWrite(redLight,HIGH);
    delay(3000);
  }

}


