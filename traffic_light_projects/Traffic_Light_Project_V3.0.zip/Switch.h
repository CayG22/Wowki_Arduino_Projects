#ifndef SWITCH_H
#define SWITCH_H
#include "Arduino.h"
class Switch{
  private:
    uint16_t repeats_since_press();
    uint8_t _pin;
    uint16_t _delay;
    uint32_t _ignore_until;
    bool _has_changed;
    int16_t _repeat_delay_ms;
    int16_t _repeat_ms;
    const bool _mode;
    bool _state;
    uint16_t _reported_repeats;
  public:
    Switch(uint8_t pin, bool mode, uint16_t debounce_ms = 100);
    bool read();
    void begin();
    void set_repeat(int16_t delay_ms, int16_t repeat_ms);
    const static int OFF = 0;
    const static int ON = 1;
};


#endif