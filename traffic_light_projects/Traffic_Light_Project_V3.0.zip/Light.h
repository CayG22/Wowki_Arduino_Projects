#ifndef LIGHT_H
#define LIGHT_H
#include "Arduino.h"
class Light{
    private:
        const uint8_t _pin;
        const bool _mode;
        int _value;
    public:
        Light(uint8_t _pin, bool _mode = OUTPUT, bool _value = LOW );
        void turnOn();
        void turnOff();

};



#endif