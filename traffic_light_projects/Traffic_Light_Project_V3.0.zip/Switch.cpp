#include "Switch.h"
#include <Arduino.h>

Switch::Switch(uint8_t pin, bool mode, uint16_t debounce_ms) : 
_pin(pin),
_mode(mode),
_delay(debounce_ms),
_ignore_until(0),
_has_changed(false),
_reported_repeats(0),
_repeat_delay_ms(-1),
_repeat_ms(-1)
{
  pinMode(_pin,_mode);

}

bool Switch::read()
{
  if(_ignore_until > millis()){}

  else if(digitalRead(_pin) != _state){
    _state = !_state;
    if(_state == OFF){
      _reported_repeats = repeats_since_press();
    }
    else{
      _reported_repeats = 0;
    }

    _ignore_until = millis() + _delay;
    _has_changed = true;
  }

  return _state;
}

uint16_t Switch::repeats_since_press()
{
 	if (_repeat_delay_ms == -1 || millis() < _ignore_until + _repeat_delay_ms)
	{
		return 0;
	}

	if (_repeat_ms <= 0)
	{
		return 1;
	}

	uint32_t press_time = millis() - _ignore_until;
	return 1 + (press_time - _repeat_delay_ms) / _repeat_ms;
}