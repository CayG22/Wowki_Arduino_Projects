#ifndef BUTTON_H
#define BUTTON_H

#include "Arduino.h";
class Button{
  private:
    const uint8_t _pin;
    uint16_t _delay;
    bool _state;
    uint32_t _ignore_until;
    bool _has_changed;
    int16_t _repeat_delay_ms;
    int16_t _repeat_ms;
    uint16_t _reported_repeats;

  public:
    Button(uint8_t pin, uint16_t debounce_ms = 100);
    void begin();
    bool read();
    bool pressed();
    bool released();
    bool toggled();
    bool has_changed();
    uint16_t repeat_count();
    void set_repeat(int16_t delay_ms, int16_t repeat_ms);
    uint16_t repeats_since_press();

    const static bool PRESSED = HIGH;
    const static bool RELEASED = LOW;
};




#endif