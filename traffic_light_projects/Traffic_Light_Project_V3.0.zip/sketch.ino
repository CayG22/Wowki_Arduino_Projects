const int greenLight = 11;
const int yellowLight = 10;
const int redLight = 9;
const int _switch = 7;
const uint16_t pedButton = A0;
const int pedLight = 12;
const int isWaitingLight = 13;
enum TrafficState{
  RED,
  GREEN,
  YELLOW,
  PEDESTRIAN_WAITING,
  PEDESTRIAN_GO,
};

TrafficState currentState = RED;
bool isWaiting = false;
unsigned long previousMillis = 0;
int buttonState = 0;
int lastButtonState = 0;
void setup() {
  Serial.begin(9600);
  // put your setup code here, to run once:
  pinMode(greenLight, OUTPUT);
  pinMode(yellowLight,OUTPUT);
  pinMode(redLight,OUTPUT);
  pinMode(_switch, INPUT_PULLUP);
  pinMode(pedButton, INPUT_PULLUP);
  pinMode(pedLight, OUTPUT);
  pinMode(isWaitingLight,OUTPUT);
  digitalWrite(redLight, HIGH);
}

void setLightsToRed(){
  digitalWrite(greenLight,LOW);
  digitalWrite(yellowLight,LOW);
  digitalWrite(redLight,HIGH);
}

void loop() {

  unsigned long currentMillis = millis();

  buttonState = digitalRead(pedButton);
  if(buttonState != lastButtonState){
    if(buttonState == HIGH){
      // If our button state is HIGH that means a pedestrian pushed the button
      isWaiting = true;
    }
    delay(50);

    lastButtonState = buttonState;
  }
  if(isWaiting)
    digitalWrite(isWaitingLight,HIGH);


  switch(currentState){
    case RED:
      if(digitalRead(_switch) == LOW){
        digitalWrite(redLight,LOW);
        digitalWrite(greenLight,HIGH);

        currentState = GREEN;
        previousMillis = currentMillis;
      }else if(digitalRead(_switch) == HIGH && isWaiting){
        currentState = PEDESTRIAN_WAITING;
        previousMillis = currentMillis;
      }
      break;
    case GREEN:
      if(currentMillis - previousMillis >= 5000){
        digitalWrite(greenLight,LOW);
        digitalWrite(yellowLight,HIGH);

        currentState = YELLOW;
        previousMillis = currentMillis;
      }
      break;
    case YELLOW:
      if(currentMillis - previousMillis >= 3000){
        digitalWrite(yellowLight,LOW);
        digitalWrite(redLight,HIGH);

        currentState = RED;
        previousMillis = currentMillis;
        if(isWaiting){
          currentState = PEDESTRIAN_WAITING;
        }
      }
      break;
    case PEDESTRIAN_WAITING:
      setLightsToRed();
      if(currentMillis - previousMillis >= 4000){
        digitalWrite(pedLight,HIGH);
        currentState = PEDESTRIAN_GO;
        previousMillis = currentMillis;
      }
      break;
    case PEDESTRIAN_GO:
      if(currentMillis - previousMillis >= 5000){
        digitalWrite(pedLight,LOW);
        isWaiting = false;
        currentState = RED;
        previousMillis = currentMillis;
      }
      break;
  }

}
