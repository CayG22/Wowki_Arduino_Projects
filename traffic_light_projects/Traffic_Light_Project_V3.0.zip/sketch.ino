#include "Light.h"
#include "Button.h"
#include "Switch.h"

enum TrafficState{
  RED,
  GREEN,
  YELLOW,
  PEDESTRIAN_WAITING,
  PEDESTRIAN_GO,
};

TrafficState currentState = RED;
Light redLight(9);
Light yellowLight(10);
Light greenLight(11);
Light pedLight(12);
Light isWaitingLight(13);
Button _pedButton(A0);
Switch _switch(7, INPUT);
bool isWaiting = false;
unsigned long previousMillis = 0;
int buttonState = 0;
int lastButtonState = 0;

void setup() {
  Serial.begin(9600);
  _pedButton.begin();

  redLight.turnOn();
}
void setLightsToRed(){
  redLight.turnOn();
  yellowLight.turnOff();
  greenLight.turnOff();
}

void loop() {

  unsigned long currentMillis = millis();
  bool switchState = _switch.read();
  if(_pedButton.pressed()){
    isWaiting = true;
  }
  if(isWaiting)
    isWaitingLight.turnOn();
  else
    isWaitingLight.turnOff();

  Serial.print(_switch.read());
  switch(currentState){

    case RED:
      if(switchState == Switch::OFF){
        redLight.turnOff();
        greenLight.turnOn();

        currentState = GREEN;
        previousMillis = currentMillis;
      }else if(switchState == Switch::ON && isWaiting){
        currentState = PEDESTRIAN_WAITING;
        previousMillis = currentMillis;
      }
      break;
    case GREEN:
      if(currentMillis - previousMillis >= 5000){
        greenLight.turnOff();
        yellowLight.turnOn();

        currentState = YELLOW;
        previousMillis = currentMillis;
      }
      break;
    case YELLOW:
      if(currentMillis - previousMillis >= 3000){
        yellowLight.turnOff();
        redLight.turnOn();

        currentState = RED;
        previousMillis = currentMillis;
        if(isWaiting){
          currentState = PEDESTRIAN_WAITING;
        }
      }
      break;
    case PEDESTRIAN_WAITING:
      setLightsToRed();
      if(currentMillis - previousMillis >= 4000){
        pedLight.turnOn();
        currentState = PEDESTRIAN_GO;
        previousMillis = currentMillis;
      }
      break;
    case PEDESTRIAN_GO:
      if(currentMillis - previousMillis >= 5000){
        pedLight.turnOff();
        isWaiting = false;
        currentState = RED;
        previousMillis = currentMillis;
      }
      break;
  }

}
