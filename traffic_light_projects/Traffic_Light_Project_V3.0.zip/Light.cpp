#include "Light.h"
#include "Arduino.h"

Light::Light(uint8_t _pin, bool _mode, bool _value)
    : _pin(_pin), _mode(_mode), _value(_value) {
      pinMode(_pin,_mode);
    }

void Light::turnOn(){
    _value = HIGH;
    digitalWrite(_pin,_value);
}
void Light::turnOff(){
    _value = LOW;
    digitalWrite(_pin,_value);
}